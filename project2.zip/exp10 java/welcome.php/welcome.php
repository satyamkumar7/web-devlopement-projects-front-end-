<?php

session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    header("location: login.php");
}


?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>PHP login system!</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Php Login System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="register.php">Register</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>

      
     
    </ul>

  <div class="navbar-collapse collapse">
  <ul class="navbar-nav ml-auto">
  <li class="nav-item active">
        <a class="nav-link" href="#"> <img src="https://img.icons8.com/metro/26/000000/guest-male.png"> <?php echo "Welcome ". $_SESSION['username']?></a>
      </li>
  </ul>
  </div>


  </div>
</nav>

<div class="container mt-4">
<h3><?php echo "Welcome ". $_SESSION['username']?>! You can now use this website</h3>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nayan designing shop</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <style>
        body{
            background-image: url('https://cdn.pixabay.com/photo/2016/11/22/21/57/apparel-1850804_960_720.jpg')
        
        }
        .container {
            color: rgb(117, 14, 78);
            border: 2px solid yellowgreen;
            width: 98vw;
            font-weight: bolder;
            /* font-family: 'Great Vibes', cursive; */
        }

        h1 {
            text-align: center;
            color: darkcyan;
        }

        h3 {
            color: darkred;
        }

        .navbar {
            background-color: black;
            border-radius: 30px;
            width:98vw;
            border: 2px solid yellowgreen;
            /* font-family: 'Great Vibes', cursive; */

        }

        .navbar ul {
            overflow: auto;
            /* position: fixed; */
        }

        .navbar li {
            float: left;
            list-style: none;
            margin: 13px 30px;
            align-items: center;


        }

        .navbar li a {
            padding: 5px 20px;
            text-decoration: none;
            color: darkmagenta;
            font-weight: bolder;
            /* position: fixed;  */
            /* top: 50px; */
            display:flex;
            align-items: center;
        }

        .navbar li a:hover {
            color: rgb(235, 10, 28)
        }

        .search {
            float: right;
            color: white;
            padding: 13px 79px
        }

        .navbar input {
            border: 2px solid black;
            border-radius: 14px;
            padding: 3px 17px;
            /* width: 129px; */
        }


        .active {
            background-color: chartreuse;
        }
        .form{
            width: 100vw;
            border: 2px solid yellowgreen;
            /* font-family: 'Great Vibes', cursive; */
        }
        #search{
            border: 2px solid cornflowerblue;
            cursor: pointer;
        }
        
    </style>
</head>

<body>
    <h1>Welcome to Costume shop</h1>
<header>
        <nav class="navbar">
            <ul>
                <li><a class="active" href="#">Home</a></li>
                <li><a href="./About.html">About</a></li>
                <li><a href="./Services.html">Services</a></li>
                <li><a href="./Contact us.html">Contact us</a></li>
                <div class="search">
                   Search:<input type="text" name="search" id="search" placeholder="Search the product">
                </div>
            </ul>
        </nav>
    </header>
</body>
<h3>This is a shop with 100% guarantee of the product that you buy.<h3>
        <div class="container">
                <!-- <img src="https://cdn.pixabay.com/photo/2016/11/22/21/57/apparel-1850804_960_720.jpg" alt="Error loading image" width="100%" 
                 height="40%">  -->
            <table>
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Product Description</th>
                        <th>Product Price</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Tresseme Shampoo</td>
                        <td>Best shampoo with the guarantee of no hairfall and no dandruff</td>
                        <td>250/- only</td>
                    </tr>
                    <tr>
                        <td>Fair & lovely facewash</td>
                        <td> facewash that guarantee to remove pimples and dirt</td>
                        <td>120/- only</td>
                    </tr>
                    <tr>
                        <td>Toys</td>
                        <td>Made in India toys</td>
                        <td>varies with product</td>
                    </tr>
                    <tr>
                        <td>Soap</td>
                        <td> soap with the guarantee of freshness and fragnance</td>
                        <td>varies with product</td>
                    </tr>
                </tbody>
            </table>

        </div>
        <hr>
        <hr>
        <div class="form">
        <h3>You need to fill this form to get the product at your Doorstep</h3>
        <form action="backend.php">
            <div>
                Name: <input type="text" name="myName">
            </div>
            <br>
            <div>
                Address: <input type="text" address="myAddress">
            </div>
            <br>
            <div>
                Mobile Number: <input type="number" name="" myMobile>
            </div>
            <br>
            <div>
                E-mail: <input type="text" name="myMail">
            </div>
            <br>
            <div>
                PIN Code: <input type="number" PIN="myPIN">
            </div>
            <br>
            <div>
                Gender: Male <input type="radio" name="myGender"> Female <input type="radio" name="myGender">
                Other <input type="radio" name="myGender">
            </div>
            <br>
            <div>
                Do you want another product: yes<input type="radio" name="AddProduct"> No <input type="radio"
                    name="AddProduct">
            </div>
            <br>
            <div>
                If yes, Add another product: <input type="text" name="AddAnotherProduct">
            </div>
            <br>
            Name the product you want to buy: <br><textarea name="myText" cols="30" rows="10"></textarea>
            <div>
                <br>
                Submit to place order: <input type="submit" value="Submit Now">
            </div>
            <br>
        </div>


        </form>
        </div>
    
        </body>

</html>
<hr>

</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
